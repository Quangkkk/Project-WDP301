const express = require("express");
const user = require("../Controller/user.controller");

const router = express.Router();

router.post("/", user.addUser);
router.get("/", user.getAllUser);
router.get("/id/:id", user.getUserById);
router.put("/:id", user.updateUserById);
router.delete("/id/:id", user.deleteUserById);

router.post("/:userId/address", user.createAddress);
router.put("/address/:addressId", user.updateAddress);
router.delete("/address/:addressId", user.deleteAddress);

module.exports = router;