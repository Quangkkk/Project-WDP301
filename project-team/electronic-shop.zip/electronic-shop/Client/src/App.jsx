import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'

import ProtectedRoute from './components/templates/ProtectedRoute.jsx'

import HomePage from './page/common/home.page.jsx'
import LoginPage from './page/common/login.page.jsx'
import RegisterPage from './page/common/register.page.jsx'
import ProductListPage from './page/common/product-list.page.jsx'
import ProductDetailPage from './page/common/product-detail.page.jsx'
import CartPage from './page/common/cart.page.jsx'
import CheckoutPage from './page/common/checkout.page.jsx'
import OrderHistoryPage from './page/common/order-history.page.jsx'
import ProfilePage from './page/common/profile.page.jsx'
import SupportPage from './page/common/support.page.jsx'

import AdminDashboardPage from './page/admin/admin-dashboard.page.jsx'
import ProductManagementPage from './page/admin/product-management.page.jsx'
import CategoryManagementPage from './page/admin/category-management.page.jsx'
import BrandManagementPage from './page/admin/brand-management.page.jsx'
import CouponManagementPage from './page/admin/coupon-management.page.jsx'
import OrderManagementPage from './page/admin/order-management.page.jsx'
import UserManagementPage from './page/admin/user-management.page.jsx'
import SupportManagementPage from './page/admin/support-management.page.jsx'

const customerOnly = ['CUSTOMER']
const backOfficeRoles = ['ADMIN', 'MANAGER', 'STAFF']
const managerRoles = ['ADMIN', 'MANAGER']
const adminOnly = ['ADMIN']

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/login' element={<LoginPage />} />
        <Route path='/register' element={<RegisterPage />} />
        <Route path='/products' element={<ProductListPage />} />
        <Route path='/products/:id' element={<ProductDetailPage />} />
        <Route path='/product' element={<Navigate to='/products' replace />} />
        <Route path='/cart' element={<CartPage />} />

        <Route
          path='/checkout'
          element={
            <ProtectedRoute allowedRoles={customerOnly}>
              <CheckoutPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/orders'
          element={
            <ProtectedRoute allowedRoles={customerOnly}>
              <OrderHistoryPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/profile'
          element={
            <ProtectedRoute>
              <ProfilePage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/support'
          element={
            <ProtectedRoute allowedRoles={customerOnly}>
              <SupportPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin'
          element={
            <ProtectedRoute allowedRoles={backOfficeRoles}>
              <AdminDashboardPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/products'
          element={
            <ProtectedRoute allowedRoles={managerRoles}>
              <ProductManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/categories'
          element={
            <ProtectedRoute allowedRoles={managerRoles}>
              <CategoryManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/brands'
          element={
            <ProtectedRoute allowedRoles={managerRoles}>
              <BrandManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/coupons'
          element={
            <ProtectedRoute allowedRoles={managerRoles}>
              <CouponManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/orders'
          element={
            <ProtectedRoute allowedRoles={backOfficeRoles}>
              <OrderManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/users'
          element={
            <ProtectedRoute allowedRoles={adminOnly}>
              <UserManagementPage />
            </ProtectedRoute>
          }
        />

        <Route
          path='/admin/support'
          element={
            <ProtectedRoute allowedRoles={backOfficeRoles}>
              <SupportManagementPage />
            </ProtectedRoute>
          }
        />

        <Route path='*' element={<Navigate to='/' replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App